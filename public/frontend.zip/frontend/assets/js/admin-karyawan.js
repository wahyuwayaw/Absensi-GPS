// admin-karyawan.js
document.addEventListener('api-ready', () => {
    const search = document.getElementById('searchInput');
    const tbody = document.querySelector('#tblKaryawan tbody');
    const btnTambah = document.getElementById('btnOpenModalTambahPegawai');
    const modalKaryawan = document.getElementById('modalKaryawan');
    const closeModalBtn = document.getElementById('closeModal');
    const btnBatal = document.getElementById('btnBatal');
    const formKaryawan = document.getElementById('formKaryawan'); // Get form reference

    // Guard jika elemen tidak ada (hindari Cannot set properties of null)
    if (!tbody || !formKaryawan) return;

    let page = 1, lastQuery = '';
    let karyawanRowsPerPage = 10; // Default rows per page

    async function loadKaryawan(p = 1, rowsPerPage = karyawanRowsPerPage) {
      try {
        page = p;
        karyawanRowsPerPage = rowsPerPage;
        const qs = new URLSearchParams({ page: String(page), per_page: String(karyawanRowsPerPage) });
        if (search && search.value) {
          qs.set('q', search.value.trim());
          lastQuery = search.value.trim();
        } else lastQuery = '';

        const { data } = await API.get('/api/karyawan?' + qs.toString());
        console.log('Karyawan API Response:', data); // Debugging line
        render(data.data.data || []);
        renderPagination(q('#pagination'), data.data, loadKaryawan, (newRowsPerPage) => loadKaryawan(1, newRowsPerPage), karyawanRowsPerPage);
      } catch (e) {
        render([], true);
        console.error('loadKaryawan failed:', e);
      }
    }

    function render(rows, isError = false) {
      console.log('Rendering Karyawan with rows:', rows); // Debugging line
      if (!rows.length) {
        tbody.innerHTML = `<tr><td class="td-text-center" colspan="7">${
          isError ? 'Gagal memuat data.' : 'Tidak ada data karyawan.'
        }</td></tr>`;
        return;
      }
      tbody.innerHTML = rows.map((r) => `
        <tr>
          <td>${r.nip || '-'}</td>
          <td>${r.nama_lengkap || '-'}</td>
          <td>${r.jabatan || '-'}</td>
          <td>${r.departemen || '-'}</td>
          <td><span class="badge ${r.status === 'aktif' ? 'approved' : 'rejected'}">${r.status || '-'}</span></td>
          <td>
            <button class="btn btn-sm" data-id="${r.id}" data-act="edit">Edit</button>
            <button class="btn btn-sm btn-danger" data-id="${r.id}" data-act="hapus">Hapus</button>
          </td>
        </tr>
      `).join('');
      // binding aksi secukupnya
      tbody.querySelectorAll('button[data-id]').forEach((b) => {
        b.onclick = async () => {
          const id = b.getAttribute('data-id');
          const act = b.getAttribute('data-act');

          if (act === 'hapus') {
            if (!confirm('Apakah Anda yakin ingin menghapus karyawan ini?')) return;
            try {
              const res = await API.req(`/api/karyawan/${id}`, { method: 'DELETE' });
              if (res.ok) {
                toast('Karyawan berhasil dihapus.');
                loadKaryawan(page); // Muat ulang halaman saat ini
              } else {
                toast(res.data?.message || 'Gagal menghapus karyawan.', 'err');
              }
            } catch (e) {
              console.error('Error deleting karyawan:', e);
              toast('Terjadi kesalahan saat menghapus karyawan.', 'err');
            }
          } else if (act === 'edit') {
            alert(`Aksi ${act} id=${id} (belum diimplementasikan)`);
            // TODO: Implementasi logika edit karyawan
          }
        };
      });
    }

    // Fungsi untuk membuka modal
    function openModal() {
      modalKaryawan.style.display = 'flex';
      document.getElementById('modalTitle').textContent = 'Tambah Karyawan';
      formKaryawan.reset(); // Clear form fields
      document.getElementById('karyawanId').value = ''; // Clear hidden ID
    }

    // Fungsi untuk menutup modal
    function closeModal() {
      modalKaryawan.style.display = 'none';
    }

    // Event Listeners
    if (btnTambah) btnTambah.onclick = openModal;
    if (closeModalBtn) closeModalBtn.onclick = closeModal;
    if (btnBatal) btnBatal.onclick = closeModal;

    // Form submission for adding/editing karyawan
    formKaryawan.addEventListener('submit', async (e) => {
      e.preventDefault(); // Prevent default form submission

      const karyawanId = document.getElementById('karyawanId').value;
      const nip = document.getElementById('nip').value.trim();
      const nama_lengkap = document.getElementById('nama_lengkap').value.trim();
      const jabatan = document.getElementById('jabatan').value.trim();
      const departemen = document.getElementById('departemen').value.trim();
      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value.trim();
      const tanggal_gabung = document.getElementById('tanggal_gabung').value;
      const status = document.getElementById('status').value;

      const payload = {
        nip,
        nama_lengkap,
        jabatan,
        departemen,
        email: email || null, // Send null if empty
        password: password || null, // Send null if empty
        tanggal_gabung: tanggal_gabung || null,
        status,
      };

      try {
        let res;
        if (karyawanId) {
          // TODO: Implement update logic
          toast('Fitur edit belum diimplementasikan.', 'info');
          return;
        } else {
          res = await API.post('/api/karyawan', payload);
        }

        if (res.ok && res.data.status) {
          toast('Karyawan berhasil disimpan.');
          closeModal();
          loadKaryawan(1); // Reload data to show new employee
        } else {
          toast(res.data?.message || 'Gagal menyimpan karyawan.', 'err');
        }
      } catch (error) {
        console.error('Error saving karyawan:', error);
        toast('Terjadi kesalahan saat menyimpan karyawan.', 'err');
      }
    });

    if (search) {
      let t;
      search.oninput = () => {
        clearTimeout(t);
        t = setTimeout(() => loadKaryawan(1), 300);
      };
    }

    // Initial load
    loadKaryawan(1);
  });