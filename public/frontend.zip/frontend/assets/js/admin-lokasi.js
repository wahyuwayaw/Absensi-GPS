// admin-lokasi.js
document.addEventListener('api-ready', () => {
  const lat = document.getElementById('lat');
  const lng = document.getElementById('lng');
  const radius = document.getElementById('radius');
  const btnSimpan = document.getElementById('btnSimpanLokasi');
  const coordText = document.getElementById('coordText');

  function showCoord() {
    if (coordText) {
      coordText.textContent = (lat?.value && lng?.value) ? `${lat.value}, ${lng.value}` : '-';
    }
  }

  if (lat) lat.oninput = showCoord;
  if (lng) lng.oninput = showCoord;

  if (btnSimpan) {
    btnSimpan.onclick = async () => {
      try {
        const payload = {
          latitude: Number(lat?.value || 0),
          longitude: Number(lng?.value || 0),
          radius: Number(radius?.value || 0),
        };
        await API.post('/api/lokasi/simpan', payload);
        alert('Lokasi disimpan.');
      } catch (e) {
        alert('Gagal simpan lokasi.');
        console.error(e);
      }
    };
  }
});
