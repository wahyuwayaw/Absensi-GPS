document.addEventListener('api-ready', () => {
  q('#btnLogout').onclick = async (e) => {
    e.preventDefault();
    await API.post('/api/logout', {});
    location.href = '../login.html';
  };

  // Fungsi untuk memuat daftar karyawan ke select
  async function loadKaryawanList() {
    const selectKaryawan = q('#karyawanSelect');
    selectKaryawan.innerHTML = '<option value="">Memuat...</option>';
    const res = await API.get('/api/karyawan'); // Mengambil semua karyawan
    console.log('Karyawan List API Response:', res); // Debugging line
    // Sesuaikan jalur data agar sesuai dengan struktur respons API
    const karyawans = res.data?.data?.data || []; // Mengambil dari res.data.data.data
    
    selectKaryawan.innerHTML = '<option value="">Pilih Karyawan</option>';
    if (karyawans.length === 0) {
      selectKaryawan.innerHTML = '<option value="">Tidak ada karyawan</option>';
      selectKaryawan.disabled = true;
    } else {
      selectKaryawan.disabled = false;
      karyawans.forEach(k => {
        const option = el('option');
        option.value = k.id;
        option.textContent = `${k.nip} - ${k.nama_lengkap}`;
        selectKaryawan.appendChild(option);
      });
    }
  }

  q('#btnCalculate').onclick = async () => { // Mengganti q('#btnCalc') dengan q('#btnCalculate')
    const karyawanId = q('#karyawanSelect').value; // Mengambil ID karyawan dari select
    const month = q('#monthPayroll').value.trim(); // Mengambil bulan dari input monthPayroll

    if (!karyawanId || !month) {
      toast('Pilih karyawan dan bulan terlebih dahulu.', 'err');
      return;
    }

    const r = await API.get(`/api/payroll/calc?karyawan_id=${encodeURIComponent(karyawanId)}&month=${encodeURIComponent(month)}`);
    
    const payrollResultDiv = q('#payrollResult');
    if (r.ok && r.data?.status) {
      const payrollData = r.data.data;
      payrollResultDiv.innerHTML = `
        <h4>Detail Gaji</h4>
        <table class="table">
          <tbody>
            <tr><td>Gaji Pokok</td><td>Rp ${payrollData.gaji_pokok?.toLocaleString('id-ID') || '0'}</td></tr>
            <tr><td>Tunjangan</td><td>Rp ${payrollData.tunjangan?.toLocaleString('id-ID') || '0'}</td></tr>
            <tr><td>Potongan</td><td>Rp ${payrollData.potongan?.toLocaleString('id-ID') || '0'}</td></tr>
            <tr><td>Gaji Bersih</td><td><strong>Rp ${payrollData.gaji_bersih?.toLocaleString('id-ID') || '0'}</strong></td></tr>
          </tbody>
        </table>
      `;
      q('#btnSlipPdf').href = `/api/payroll/slip.pdf?karyawan_id=${encodeURIComponent(karyawanId)}&month=${encodeURIComponent(month)}`;
      q('#btnSlipPdf').disabled = false;
    } else {
      payrollResultDiv.innerHTML = `<p class="muted">Gagal menghitung gaji: ${r.data?.message || 'Terjadi kesalahan.'}</p>`;
      q('#btnSlipPdf').disabled = true;
    }
  };

  // Panggil fungsi untuk memuat daftar karyawan saat halaman dimuat
  loadKaryawanList();
});
