document.addEventListener('DOMContentLoaded', () => {
  q('#btnLogout').onclick = async (e) => {
    e.preventDefault();
    await API.post('/api/logout', {});
    location.href = '../login.html';
  };

  (async () => {
    const me = await API.get('/api/me');
    q('#adminNamaInput').value = me?.data?.nama || '';
    q('#adminUsernameInput').value = me?.data?.username || '';
  })();

  q('#formAdminProfile').onsubmit = async (e) => {
    e.preventDefault();
    const r = await API.put('/api/admin/profile', {
      nama: q('#adminNamaInput').value,
      username: q('#adminUsernameInput').value
    });
    r.status ? toast('Tersimpan') : toast(r.message || 'Gagal');
  };

  q('#formAdminPassword').onsubmit = async (e) => {
    e.preventDefault();
    const r = await API.put('/api/admin/profile/password', {
      current: q('[name="current"]').value,
      new: q('[name="new"]').value
    });
    r.status ? toast('Password diubah') : toast(r.message || 'Gagal');
  };

  q('#btnHealthCheck').onclick = async () => {
    const r = await API.get('/api/admin/health');
    q('#healthStatus').textContent = JSON.stringify(r?.data || r, null, 2);
  };

  q('#btnLogoutAll').onclick = async () => {
    const r = await API.post('/api/admin/sessions/logout-all', {});
    r.status ? toast('Semua sesi logout') : toast(r.message || 'Gagal');
  };
});