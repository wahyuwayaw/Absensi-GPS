// public/frontend/assets/js/common.js

/**
 * Mendeklarasikan window.toast agar linter mengenalinya
 * Fungsi toast dipanggil di semua file JS
 */
window.toast = function(msg, type = 'info'){
  const el = document.createElement('div');
  el.textContent = msg;
  // CSS inline untuk notifikasi pop-up
  el.classList.add('toast');
  if(type === 'err') el.classList.add('toast-error');
  document.body.appendChild(el); 
  setTimeout(() => el.remove(), 2600);
};



/**
 * Objek API untuk menangani semua request ke backend
 * Dibungkus dalam IIFE (Immediately Invoked Function Expression) async
 * untuk memastikan token CSRF diambil sebelum API siap digunakan.
 */
(async () => {
  // Fungsi untuk mendapatkan CSRF Token (Wajib untuk Sanctum)
  async function getCsrfToken() {
    try {
      // Cukup panggil endpoint ini, browser akan otomatis menyimpan cookie
      await fetch('/sanctum/csrf-cookie', { credentials: 'include' });
      console.log('CSRF token fetched successfully.');
      return true;
    } catch (e) {
      console.error('Failed to fetch CSRF token:', e);
      // Jika gagal mendapatkan token, mungkin tampilkan pesan error ke user
      document.body.innerHTML = 'Error: Could not connect to the server. Please check your network and refresh the page.';
      return false;
    }
  }

  // Fungsi untuk membaca nilai cookie
  function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
  }

  // Ambil token CSRF terlebih dahulu
  await getCsrfToken();

  // Definisikan objek API setelah token didapatkan
  const API = {
    // Fungsi dasar untuk fetch request
    async req(url, opt = {}){
      const res = await fetch(url, {
        credentials: 'include', // Wajib untuk mengirim cookie (termasuk session & XSRF)
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json', // Pastikan server tahu kita mau JSON
          'X-XSRF-TOKEN': decodeURIComponent(getCookie('XSRF-TOKEN')), // Tambahkan header XSRF
          ...(opt.headers || {})
        }, 
        ...opt
      });
      
      const txt = await res.text();
      
      // Penanganan jika sesi berakhir -> redirect ke login
      if (res.status === 401 || res.status === 419) { // 401 Unauthorized, 419 CSRF Token Mismatch/Expired
        toast('Sesi Anda telah berakhir, silakan login kembali.', 'err');
        setTimeout(() => {
          // Cek lokasi saat ini untuk menentukan path ke login.html
          if (window.location.pathname.includes('/admin/')) {
            window.location.href = '../login.html';
          } else if (window.location.pathname.includes('/karyawan/')) {
            window.location.href = '../login.html';
          } else {
            window.location.href = 'login.html';
          }
        }, 2000);
        return {ok: false, code: res.status, data: {status: false, message: 'Sesi berakhir.'}};
      }

      try { 
        const json = JSON.parse(txt);
        return {ok: res.ok, code: res.status, data: json}; 
      }
      catch(e){ 
        return {
          ok: false, 
          code: res.status, 
          data: {status: false, message: `Server error: ${txt.slice(0, 240)}`}
        }; 
      }
    },
    
    // Method GET (Sederhana)
    get: (url) => API.req(url),
    
    // Method POST (Dengan body JSON)
    post: (url, body) => API.req(url, {method: 'POST', body: JSON.stringify(body)}),
    
    // Method PUT (Dengan body JSON)
    put: (url, body) => API.req(url, {method: 'PUT', body: JSON.stringify(body)}),

    // Method PATCH (Dengan body JSON)
    patch: (url, body) => API.req(url, {method: 'PATCH', body: JSON.stringify(body)}),
    
    // Method POST untuk FormData (Multipart)
    async postForm(url, form){
      // Untuk FormData, browser akan set Content-Type secara otomatis
      const res = await fetch(url, {method: 'POST', credentials: 'include', body: form, headers: {'Accept': 'application/json'}});
      const t = await res.text(); 
      try{
          return {ok: res.ok, code: res.status, data: JSON.parse(t)}
      } catch {
          return {ok: false, code: res.status, data: {status: false, message: t}}
      } 
    }
  };

  // Pastikan API diexport ke window agar bisa diakses di file lain
  window.API = API;

  // Kirim event custom untuk menandakan bahwa API sudah siap
  document.dispatchEvent(new Event('api-ready'));
})();


// Fungsi helper untuk querySelector
if (typeof window.q === 'undefined') { // Pastikan hanya didefinisikan sekali
  window.q = (selector) => document.querySelector(selector);
}
// Fungsi helper untuk createElement
if (typeof window.el === 'undefined') { // Pastikan hanya didefinisikan sekali
  window.el = (tagName, innerHTML = '') => {
    const element = document.createElement(tagName);
    element.innerHTML = innerHTML;
    return element;
  };
}