document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('label.btn-ghost').forEach(l => {
    l.addEventListener('click', () => {
      document.querySelectorAll('label.btn-ghost').forEach(x => x.classList.remove('btn-primary'));
      l.classList.add('btn-primary');
      const radioInput = l.querySelector('input');
      radioInput.checked = true;
      
      // Ubah placeholder berdasarkan peran yang dipilih
      const usernameInput = document.getElementById('username');
      if (radioInput.value === 'admin') {
        usernameInput.placeholder = 'Username';
      } else if (radioInput.value === 'karyawan') {
        usernameInput.placeholder = 'NIP';
      }
    });
  });

  // Atur status awal tombol peran
  const initialCheckedLabel = document.querySelector('input[name=role]:checked').closest('label.btn-ghost');
  initialCheckedLabel.classList.add('btn-primary');

  // Atur placeholder awal berdasarkan peran yang dipilih
  const initialRole = document.querySelector('input[name=role]:checked').value;
  const usernameInput = document.getElementById('username');
  if (initialRole === 'admin') {
    usernameInput.placeholder = 'Username';
  } else if (initialRole === 'karyawan') {
    usernameInput.placeholder = 'NIP';
  }

  document.getElementById('btnLogin').onclick = async () => {
    const role = document.querySelector('input[name=role]:checked').value;
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
    if (!username || !password) {
      toast('Lengkapi username & password', 'err');
      return;
    }
    const r = await API.post('/api/login', {
      role,
      username,
      password
    });
    if (!r.ok || r.data.status === false) {
      toast(r.data.message || 'Login gagal', 'err');
      return;
    }
    location.href = role === 'admin' ? 'admin/index.html' : 'karyawan/index.html';
  };

  // --- Helper function to capture face image (Interactive Version) ---
  async function captureFaceImage() {
    console.log('captureFaceImage: Function started');
    let stream = null;
    let video = null;
    let canvas = null;
    let cameraContainer = null;
    let takePhotoButton = null;
    let cancelButton = null;
    let sendPhotoButton = null;
    let retakePhotoButton = null;

    const cleanup = () => {
      console.log('Performing cleanup...');
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      if (cameraContainer && cameraContainer.parentNode === document.body) {
        document.body.removeChild(cameraContainer);
      }
    };

    return new Promise(async (resolve, reject) => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
        console.log('captureFaceImage: getUserMedia called');

        cameraContainer = document.createElement('div');
        cameraContainer.id = 'camera-container';
        cameraContainer.style.position = 'fixed';
        cameraContainer.style.top = '0';
        cameraContainer.style.left = '0';
        cameraContainer.style.width = '100%';
        cameraContainer.style.height = '100%';
        cameraContainer.style.backgroundColor = 'rgba(0,0,0,0.8)';
        cameraContainer.style.display = 'flex';
        cameraContainer.style.flexDirection = 'column';
        cameraContainer.style.justifyContent = 'center';
        cameraContainer.style.alignItems = 'center';
        cameraContainer.style.zIndex = '9999';
        document.body.appendChild(cameraContainer);

        video = document.createElement('video');
        video.style.width = '80%';
        video.style.maxWidth = '640px';
        video.style.height = 'auto';
        video.style.backgroundColor = 'black';
        video.style.marginBottom = '10px';
        cameraContainer.appendChild(video);

        video.srcObject = stream;
        await video.play();

        canvas = document.createElement('canvas');
        canvas.style.display = 'none'; // Initially hidden, used for preview
        canvas.style.width = '80%';
        canvas.style.maxWidth = '640px';
        canvas.style.height = 'auto';
        canvas.style.backgroundColor = 'black';
        canvas.style.marginBottom = '10px';
        cameraContainer.appendChild(canvas);

        const context = canvas.getContext('2d');

        takePhotoButton = document.createElement('button');
        takePhotoButton.textContent = 'Ambil Foto';
        takePhotoButton.style.padding = '10px 20px';
        takePhotoButton.style.fontSize = '1.2em';
        takePhotoButton.style.margin = '5px';
        cameraContainer.appendChild(takePhotoButton);

        cancelButton = document.createElement('button');
        cancelButton.textContent = 'Batal';
        cancelButton.style.padding = '10px 20px';
        cancelButton.style.fontSize = '1.2em';
        cancelButton.style.margin = '5px';
        cancelButton.style.backgroundColor = '#dc3545';
        cancelButton.style.color = 'white';
        cancelButton.style.border = 'none';
        cancelButton.style.borderRadius = '5px';
        cancelButton.style.cursor = 'pointer';
        cameraContainer.appendChild(cancelButton);

        sendPhotoButton = document.createElement('button');
        sendPhotoButton.textContent = 'Kirim Foto';
        sendPhotoButton.style.padding = '10px 20px';
        sendPhotoButton.style.fontSize = '1.2em';
        sendPhotoButton.style.margin = '5px';
        sendPhotoButton.style.display = 'none'; // Initially hidden
        cameraContainer.appendChild(sendPhotoButton);

        retakePhotoButton = document.createElement('button');
        retakePhotoButton.textContent = 'Ulangi';
        retakePhotoButton.style.padding = '10px 20px';
        retakePhotoButton.style.fontSize = '1.2em';
        retakePhotoButton.style.margin = '5px';
        retakePhotoButton.style.backgroundColor = '#ffc107'; // Yellow for retake
        retakePhotoButton.style.color = 'white';
        retakePhotoButton.style.border = 'none';
        retakePhotoButton.style.borderRadius = '5px';
        retakePhotoButton.style.cursor = 'pointer';
        retakePhotoButton.style.display = 'none'; // Initially hidden
        cameraContainer.appendChild(retakePhotoButton);

        const showLiveCamera = () => {
          video.style.display = 'block';
          canvas.style.display = 'none';
          takePhotoButton.style.display = 'block';
          cancelButton.style.display = 'block';
          sendPhotoButton.style.display = 'none';
          retakePhotoButton.style.display = 'none';
          video.play();
        };

        const showCapturedImage = () => {
          video.pause();
          video.style.display = 'none';
          canvas.style.display = 'block';
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;
          context.drawImage(video, 0, 0, canvas.width, canvas.height);
          takePhotoButton.style.display = 'none';
          cancelButton.style.display = 'none';
          sendPhotoButton.style.display = 'block';
          retakePhotoButton.style.display = 'block';
        };

        takePhotoButton.onclick = showCapturedImage;

        sendPhotoButton.onclick = () => {
          console.log('Kirim Foto button clicked');
          const imageData = canvas.toDataURL('image/jpeg');
          console.log('captureFaceImage: Image sent by user');
          resolve(imageData);
          console.log('Promise resolved with image data');
        };

        retakePhotoButton.onclick = showLiveCamera;

        cancelButton.onclick = () => {
          console.log('Batal button clicked');
          reject('Pengambilan foto dibatalkan.');
          console.log('Promise explicitly rejected with:', 'Pengambilan foto dibatalkan.');
        };

      } catch (error) {
        console.error('captureFaceImage: Error in try block:', error);
        let errorMessage = 'Gagal mengakses kamera.';
        if (error.name === 'NotAllowedError') {
          errorMessage = 'Akses kamera ditolak. Mohon izinkan akses kamera di browser Anda.';
        } else if (error.name === 'NotFoundError') {
          errorMessage = 'Kamera tidak ditemukan.';
        } else if (error.name === 'NotReadableError') {
          errorMessage = 'Kamera sedang digunakan oleh aplikasi lain.';
        }
        reject(errorMessage);
      }
    }).finally(cleanup); // Attach cleanup to the promise's finally block
  }

  document.getElementById('btnFace').onclick = async () => {
    const role = document.querySelector('input[name=role]:checked').value;
    const username = document.getElementById('username').value.trim();
    if (!username) {
      toast('Isi username/NIP dulu', 'err');
      return;
    }
    try {
      const image = await captureFaceImage(); // Use the interactive camera
      const r = await API.post('/api/face/login', {
        role,
        username,
        image: image
      });
      if (!r.ok || r.data.status === false) {
        toast(r.data.message || 'Face login gagal', 'err');
        return;
      }
      location.href = role === 'admin' ? 'admin/index.html' : 'karyawan/index.html';
    } catch (error) {
      console.error('Face login failed:', error);
      toast(error || 'Face login dibatalkan atau gagal.', 'err');
    }
  };
});