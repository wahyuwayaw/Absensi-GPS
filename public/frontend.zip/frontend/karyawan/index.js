document.addEventListener('api-ready', () => {
  const digitalClock = document.getElementById('digitalClock');
  const btnCheckin = document.getElementById('btnCheckin');
  const btnCheckout = document.getElementById('btnCheckout');
  const statusHariIniEl = document.getElementById('statusHariIni');
  const tblRiwayatTerbaruBody = document.querySelector('#tblRiwayatTerbaru tbody');
  const userAvatar = document.getElementById('userAvatar');
  const userAvatarDropdown = document.getElementById('userAvatarDropdown');
  const btnLogout = document.getElementById('btnLogout');

  // Permohonan Form Elements
  const formPermohonanDashboard = document.getElementById('formPermohonanDashboard');
  const tipePermohonanDashboard = document.getElementById('tipePermohonanDashboard');
  const tanggalMulaiDashboard = document.getElementById('tanggalMulaiDashboard');
  const tanggalSelesaiDashboard = document.getElementById('tanggalSelesaiDashboard');
  const alasanPermohonanDashboard = document.getElementById('alasanPermohonanDashboard');
  const buktiPermohonanDashboard = document.getElementById('buktiPermohonanDashboard');

  const tblRiwayatPermohonanTerbaruBody = document.querySelector('#tblRiwayatPermohonanTerbaru tbody');


  let currentUser = null; // To store current user data

  // --- Helper function to querySelector ---
  function qs(s){return document.querySelector(s)}

  // --- Digital Clock ---
  function updateClock() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    digitalClock.textContent = `${hours}:${minutes}:${seconds}`;
  }
  setInterval(updateClock, 1000);
  updateClock(); // Initial call

  // --- User Avatar Dropdown Logic ---
  userAvatar.addEventListener('click', () => {
      userAvatarDropdown.classList.toggle('show');
  });
  // Close dropdown if clicked outside
  window.addEventListener('click', (e) => {
      if (!userAvatar.contains(e.target) && !userAvatarDropdown.contains(e.target)) {
          userAvatarDropdown.classList.remove('show');
      }
  });

  // --- Load User Data for Avatar ---
  async function loadUserData() {
      const meRes = await API.get('/api/me');
      if (meRes.ok && meRes.data.status) {
          currentUser = meRes.data.data;
          if (currentUser && currentUser.nama_lengkap) {
              userAvatar.textContent = currentUser.nama_lengkap.charAt(0).toUpperCase();
          } else {
              userAvatar.textContent = '?';
          }
      } else {
          toast(meRes.data?.message || 'Gagal memuat data pengguna.', 'err');
      }
  }

  // --- Load Today's Status ---
  async function loadTodayStatus() {
    const todayRes = await API.get('/api/karyawan/today');
    if (todayRes.ok && todayRes.data.status) {
      const data = todayRes.data.data;
      if (data) {
        statusHariIniEl.textContent = data.status ? data.status.toUpperCase() : 'BELUM ABSEN';
        btnCheckin.disabled = !!data.waktu_masuk; // Disable if already checked in
        btnCheckout.disabled = !data.waktu_masuk || !!data.waktu_pulang; // Disable if not checked in or already checked out
      } else {
        statusHariIniEl.textContent = 'BELUM ABSEN';
        btnCheckin.disabled = false;
        btnCheckout.disabled = true;
      }
    } else {
      toast(todayRes.data?.message || 'Gagal memuat status hari ini.', 'err');
      btnCheckin.disabled = true;
      btnCheckout.disabled = true;
    }
  }

  // --- Load Latest History ---
  async function loadLatestHistory() {
    const historyRes = await API.get('/api/karyawan/absensi?days=7'); // Last 7 days
    if (historyRes.ok && historyRes.data.status && Array.isArray(historyRes.data.data)) {
      tblRiwayatTerbaruBody.innerHTML = historyRes.data.data.slice(0, 5).map(a => `
        <tr>
          <td>${a.tanggal || '-'}</td>
          <td>${a.waktu_masuk || '-'}</td>
          <td>${a.waktu_pulang || '-'}</td>
          <td><span class="badge ${a.status === 'hadir' ? 'approved' : (a.status === 'absen' ? 'rejected' : 'pending')}">${a.status.toUpperCase()}</span></td>
          <td>${a.telat_menit > 0 ? a.telat_menit : '0'}</td>
        </tr>
      `).join('');
    } else {
      tblRiwayatTerbaruBody.innerHTML = `<tr><td colspan="5" class="td-text-center td-small-muted">Tidak ada riwayat absensi.</td></tr>`;
    }
  }

  // --- Load Latest Permohonan History ---
  async function loadLatestPermohonanHistory() {
    const permohonanRes = await API.get('/api/karyawan/permohonan?per_page=5'); // Get latest 5 applications
    if (permohonanRes.ok && permohonanRes.data.status && Array.isArray(permohonanRes.data.data.data)) {
        tblRiwayatPermohonanTerbaruBody.innerHTML = permohonanRes.data.data.data.map(p => `
            <tr>
                <td>${p.tipe || '-'}</td>
                <td><span class="badge ${p.status === 'approved' ? 'approved' : (p.status === 'rejected' ? 'rejected' : 'pending')}">${p.status.toUpperCase()}</span></td>
            </tr>
        `).join('');
    } else {
        tblRiwayatPermohonanTerbaruBody.innerHTML = `<tr><td colspan="2" class="td-text-center td-small-muted">Tidak ada permohonan.</td></tr>`;
    }
  }

  // --- Permohonan Form Submission Logic (Integrated from permohonan.js) ---
  formPermohonanDashboard.addEventListener('submit', async (e) => {
      e.preventDefault();

      const tipe = tipePermohonanDashboard.value;
      const tanggal_mulai = tanggalMulaiDashboard.value;
      const tanggal_selesai = tanggalSelesaiDashboard.value;
      const alasan = alasanPermohonanDashboard.value.trim();
      const buktiFile = buktiPermohonanDashboard.files[0];

      const formData = new FormData();
      formData.append('tipe', tipe);
      formData.append('tanggal_mulai', tanggal_mulai);
      if (tanggal_selesai) formData.append('tanggal_selesai', tanggal_selesai);
      if (alasan) formData.append('alasan', alasan);
      if (buktiFile) formData.append('bukti', buktiFile);

      try {
          const res = await API.postForm('/api/karyawan/permohonan', formData); // Use postForm for FormData
          if (res.ok && res.data.status) {
              toast('Permohonan berhasil diajukan.');
              formPermohonanDashboard.reset(); // Clear form fields
              loadLatestPermohonanHistory(); // Reload latest permohonan history
          } else {
              toast(res.data?.message || 'Gagal mengajukan permohonan.', 'err');
          }
      } catch (error) {
          console.error('Error submitting permohonan:', error);
          toast('Terjadi kesalahan saat mengajukan permohonan.', 'err');
      }
  });


  // --- Helper function to get geolocation ---
  function getGeolocation() {
    return new Promise((resolve, reject) => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            resolve({
              lat: position.coords.latitude,
              lng: position.coords.longitude,
            });
          },
          (error) => {
            console.error('Error getting geolocation:', error); // Corrected error message
            console.log('Geolocation error code:', error.code);
            console.log('Geolocation error message:', error.message);
            let errorMessage = 'Gagal mendapatkan lokasi.';
            switch (error.code) {
              case error.PERMISSION_DENIED:
                errorMessage = 'Akses lokasi ditolak. Mohon izinkan akses lokasi di browser Anda.';
                break;
              case error.POSITION_UNAVAILABLE:
                errorMessage = 'Informasi lokasi tidak tersedia.';
                break;
              case error.TIMEOUT:
                errorMessage = 'Permintaan lokasi habis waktu.';
                break;
              case error.UNKNOWN_ERROR:
                errorMessage = 'Terjadi kesalahan yang tidak diketahui saat mendapatkan lokasi.';
                break;
            }
            reject(errorMessage);
          },
          { enableHighAccuracy: false, timeout: 20000, maximumAge: 0 }
        );
      } else {
        reject('Geolocation tidak didukung oleh browser Anda.');
      }
    });
  }

  // --- Helper function to capture face image (Interactive Version) ---
  async function captureFaceImage() {
    console.log('captureFaceImage: Function started');
    let stream = null;
    let video = null;
    let canvas = null;
    let cameraContainer = null;
    let takePhotoButton = null;
    let cancelButton = null;
    let sendPhotoButton = null;
    let retakePhotoButton = null;

    const cleanup = () => {
      console.log('Performing cleanup...');
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      if (cameraContainer && cameraContainer.parentNode === document.body) {
        document.body.removeChild(cameraContainer);
      }
    };

    return new Promise(async (resolve, reject) => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
        console.log('captureFaceImage: getUserMedia called');

        cameraContainer = document.createElement('div');
        cameraContainer.id = 'camera-container';
        cameraContainer.style.position = 'fixed';
        cameraContainer.style.top = '0';
        cameraContainer.style.left = '0';
        cameraContainer.style.width = '100%';
        cameraContainer.style.height = '100%';
        cameraContainer.style.backgroundColor = 'rgba(0,0,0,0.8)';
        cameraContainer.style.display = 'flex';
        cameraContainer.style.flexDirection = 'column';
        cameraContainer.style.justifyContent = 'center';
        cameraContainer.style.alignItems = 'center';
        cameraContainer.style.zIndex = '9999';
        document.body.appendChild(cameraContainer);

        video = document.createElement('video');
        video.style.width = '80%';
        video.style.maxWidth = '640px';
        video.style.height = 'auto';
        video.style.backgroundColor = 'black';
        video.style.marginBottom = '10px';
        cameraContainer.appendChild(video);

        video.srcObject = stream;
        await video.play();

        canvas = document.createElement('canvas');
        canvas.style.display = 'none'; // Initially hidden, used for preview
        canvas.style.width = '80%';
        canvas.style.maxWidth = '640px';
        canvas.style.height = 'auto';
        canvas.style.backgroundColor = 'black';
        canvas.style.marginBottom = '10px';
        cameraContainer.appendChild(canvas);

        const context = canvas.getContext('2d');

        takePhotoButton = document.createElement('button');
        takePhotoButton.textContent = 'Ambil Foto';
        takePhotoButton.style.padding = '10px 20px';
        takePhotoButton.style.fontSize = '1.2em';
        takePhotoButton.style.margin = '5px';
        cameraContainer.appendChild(takePhotoButton);

        cancelButton = document.createElement('button');
        cancelButton.textContent = 'Batal';
        cancelButton.style.padding = '10px 20px';
        cancelButton.style.fontSize = '1.2em';
        cancelButton.style.margin = '5px';
        cancelButton.style.backgroundColor = '#dc3545';
        cancelButton.style.color = 'white';
        cancelButton.style.border = 'none';
        cancelButton.style.borderRadius = '5px';
        cancelButton.style.cursor = 'pointer';
        cameraContainer.appendChild(cancelButton);

        sendPhotoButton = document.createElement('button');
        sendPhotoButton.textContent = 'Kirim Foto';
        sendPhotoButton.style.padding = '10px 20px';
        sendPhotoButton.style.fontSize = '1.2em';
        sendPhotoButton.style.margin = '5px';
        sendPhotoButton.style.display = 'none'; // Initially hidden
        cameraContainer.appendChild(sendPhotoButton);

        retakePhotoButton = document.createElement('button');
        retakePhotoButton.textContent = 'Ulangi';
        retakePhotoButton.style.padding = '10px 20px';
        retakePhotoButton.style.fontSize = '1.2em';
        retakePhotoButton.style.margin = '5px';
        retakePhotoButton.style.backgroundColor = '#ffc107'; // Yellow for retake
        retakePhotoButton.style.color = 'white';
        retakePhotoButton.style.border = 'none';
        retakePhotoButton.style.borderRadius = '5px';
        retakePhotoButton.style.cursor = 'pointer';
        retakePhotoButton.style.display = 'none'; // Initially hidden
        cameraContainer.appendChild(retakePhotoButton);

        const showLiveCamera = () => {
          video.style.display = 'block';
          canvas.style.display = 'none';
          takePhotoButton.style.display = 'block';
          cancelButton.style.display = 'block';
          sendPhotoButton.style.display = 'none';
          retakePhotoButton.style.display = 'none';
          video.play();
        };

        const showCapturedImage = () => {
          video.pause();
          video.style.display = 'none';
          canvas.style.display = 'block';
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;
          context.drawImage(video, 0, 0, canvas.width, canvas.height);
          takePhotoButton.style.display = 'none';
          cancelButton.style.display = 'none';
          sendPhotoButton.style.display = 'block';
          retakePhotoButton.style.display = 'block';
        };

        takePhotoButton.onclick = showCapturedImage;

        sendPhotoButton.onclick = () => {
          console.log('Kirim Foto button clicked');
          const imageData = canvas.toDataURL('image/jpeg');
          console.log('captureFaceImage: Image sent by user');
          resolve(imageData);
          console.log('Promise resolved with image data');
        };

        retakePhotoButton.onclick = showLiveCamera;

        cancelButton.onclick = () => {
          console.log('Batal button clicked');
          reject('Pengambilan foto dibatalkan.');
          console.log('Promise explicitly rejected with:', 'Pengambilan foto dibatalkan.');
        };

      } catch (error) {
        console.error('captureFaceImage: Error in try block:', error);
        let errorMessage = 'Gagal mengakses kamera.';
        if (error.name === 'NotAllowedError') {
          errorMessage = 'Akses kamera ditolak. Mohon izinkan akses kamera di browser Anda.';
        } else if (error.name === 'NotFoundError') {
          errorMessage = 'Kamera tidak ditemukan.';
        } else if (error.name === 'NotReadableError') {
          errorMessage = 'Kamera sedang digunakan oleh aplikasi lain.';
        }
        reject(errorMessage);
      }
    }).finally(cleanup); // Attach cleanup to the promise's finally block
  }

  // --- Check In/Check Out Actions ---
  btnCheckin.onclick = async () => {
    try {
      const { lat, lng } = await getGeolocation(); // Restored original call
      const image = await captureFaceImage(); // Capture face image
      console.log('Image data length (Checkin):', image ? image.length : 'null'); // Added log
      const res = await API.post('/api/absensi/checkin', { lat, lng, image });
      console.log('API response (Checkin):', res); // Added log
      if (res.ok && res.data.status) {
        toast('Check-in berhasil!');
        loadTodayStatus();
        loadLatestHistory();
      } else {
        toast(res.data?.message || 'Check-in gagal.', 'err');
      }
    } catch (error) {
      console.log('Promise rejected with:', error);
      toast(error, 'err');
    }
  };

  btnCheckout.onclick = async () => {
    try {
      const { lat, lng } = await getGeolocation(); // Restored original call
      const image = await captureFaceImage(); // Capture face image
      console.log('Image data length (Checkout):', image ? image.length : 'null'); // Added log
      const res = await API.post('/api/absensi/checkout', { lat, lng, image });
      console.log('API response (Checkout):', res); // Added log
      if (res.ok && res.data.status) {
        toast('Check-out berhasil!');
        loadTodayStatus();
        loadLatestHistory();
      } else {
        toast(res.data?.message || 'Check-out gagal.', 'err');
      }
    } catch (error) {
      console.log('Promise rejected with:', error);
      toast(error, 'err');
    }
  };

  // --- Initial Loads ---
  loadUserData(); // Load user data for avatar
  loadTodayStatus();
  loadLatestHistory();
  loadLatestPermohonanHistory(); // Load new permohonan history
  btnLogout.onclick = async ()=>{ await API.post('/api/logout',{}); location.href='../login.html'; };
});