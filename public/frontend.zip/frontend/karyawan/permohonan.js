document.addEventListener('api-ready', () => {
    const tblPermohonanBody = document.querySelector('#tblPermohonan tbody');

    let currentPermohonanPage = 1;
    let permohonanRowsPerPage = 10;

    async function loadPermohonanHistory(page = 1, rowsPerPage = permohonanRowsPerPage) {
        currentPermohonanPage = page;
        permohonanRowsPerPage = rowsPerPage;
        const qs = new URLSearchParams({ page: String(currentPermohonanPage), per_page: String(permohonanRowsPerPage) });

        try { // Moved try block inside the function
            const historyRes = await API.get('/api/karyawan/permohonan?' + qs.toString());
            if (historyRes.ok && historyRes.data.status && Array.isArray(historyRes.data.data.data)) {
                tblPermohonanBody.innerHTML = historyRes.data.data.data.map(p => `
                    <tr>
                        <td>${p.created_at?.slice(0,10) || '-'}</td>
                        <td>${p.tipe || '-'}</td>
                        <td>${p.tanggal_mulai || '-'}</td>
                        <td>${p.tanggal_selesai || '-'}</td>
                        <td>${p.alasan || '-'}</td>
                        <td><span class="badge ${p.status === 'approved' ? 'approved' : (p.status === 'rejected' ? 'rejected' : 'pending')}">${p.status.toUpperCase()}</span></td>
                        <td>${p.catatan_admin || '-'}</td>
                        <td>${p.bukti_path ? `<a href="/storage/${p.bukti_path.replace(/^public\//,'')}" target="_blank">Lihat Bukti</a>` : '-'}</td>
                    </tr>
                `).join('');
                renderPagination(q('#pagination'), historyRes.data.data, loadPermohonanHistory, (newRowsPerPage) => loadPermohonanHistory(1, newRowsPerPage), permohonanRowsPerPage);
            } else {
                tblPermohonanBody.innerHTML = `<tr><td colspan="8" class="td-text-center td-small-muted">Tidak ada riwayat permohonan.</td></tr>`;
                renderPagination(q('#pagination'), { current_page: 1, last_page: 1, from: 0, to: 0, total: 0 }, loadPermohonanHistory, (newRowsPerPage) => loadPermohonanHistory(1, newRowsPerPage), permohonanRowsPerPage);
            }
        } catch (error) { // Moved catch block inside the function
            console.error('loadPermohonanHistory failed:', error);
            toast('Gagal memuat riwayat permohonan.', 'err');
            tblPermohonanBody.innerHTML = `<tr><td colspan="8" class="td-text-center td-small-muted">Gagal memuat riwayat permohonan.</td></tr>`;
            renderPagination(q('#pagination'), { current_page: 1, last_page: 1, from: 0, to: 0, total: 0 }, loadPermohonanHistory, (newRowsPerPage) => loadPermohonanHistory(1, newRowsPerPage), permohonanRowsPerPage);
        }
    }

    // Initial load
    loadPermohonanHistory();

    function qs(s){return document.querySelector(s)}
});