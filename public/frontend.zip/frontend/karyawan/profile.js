document.addEventListener('api-ready', () => {
    const segmentedControl = document.querySelector('.segmented-control');
    const profilCard = document.getElementById('profilCard');
    const editDataCard = document.getElementById('editDataCard');
    const gantiPasswordCard = document.getElementById('gantiPasswordCard');
    const userAvatar = document.getElementById('userAvatar');
    const userAvatarDropdown = document.getElementById('userAvatarDropdown');
    const btnLogout = document.getElementById('btnLogout');
    const btnChangePhoto = document.getElementById('btnChangePhoto');
    const btnChangePasswordDropdown = document.getElementById('btnChangePasswordDropdown');
    const btnBackToHome = document.getElementById('btnBackToHome');

    // Profile View Elements
    const profileImagePreview = document.getElementById('profileImagePreview');
    const profileInitials = document.getElementById('profileInitials');
    const photoUploadInput = document.getElementById('photoUploadInput');
    const btnUploadPhoto = document.getElementById('btnUploadPhoto');
    const btnRemovePhoto = document.getElementById('btnRemovePhoto');
    const viewNip = document.getElementById('viewNip');
    const viewNamaLengkap = document.getElementById('viewNamaLengkap');
    const viewJabatan = document.getElementById('viewJabatan');
    const viewDepartemen = document.getElementById('viewDepartemen');
    const viewEmail = document.getElementById('viewEmail');
    const viewStatus = document.getElementById('viewStatus');

    // Edit Data Form Elements
    const formEditProfile = document.getElementById('formEditProfile');
    const editNip = document.getElementById('editNip');
    const editNamaLengkap = document.getElementById('editNamaLengkap');
    const editJabatan = document.getElementById('editJabatan');
    const editDepartemen = document.getElementById('editDepartemen');
    const editEmail = document.getElementById('editEmail');
    const editStatus = document.getElementById('editStatus');
    const btnResetEditProfile = document.getElementById('btnResetEditProfile');

    // Change Password Form Elements
    const formChangePassword = document.getElementById('formChangePassword');
    const currentPassword = document.getElementById('current_password');
    const newPassword = document.getElementById('new_password');
    const confirmNewPassword = document.getElementById('confirm_new_password');

    let currentUser = null; // To store current user data

    // --- Helper function to querySelector ---
    function qs(s){return document.querySelector(s)}

    // --- Tab Switching Logic (Show/Hide Cards) ---
    function showTab(tabId) {
        // Hide all cards first
        profilCard.style.display = 'none';
        editDataCard.style.display = 'none';
        gantiPasswordCard.style.display = 'none';

        // Show the active card
        if (tabId === 'profilTab') {
            profilCard.style.display = 'block';
        } else if (tabId === 'editDataTab') {
            editDataCard.style.display = 'block';
        } else if (tabId === 'gantiPasswordTab') {
            gantiPasswordCard.style.display = 'block';
        }

        // Update active state of segmented control buttons
        segmentedControl.querySelectorAll('button').forEach(button => {
            button.classList.remove('active');
            if (button.dataset.tab === tabId.replace('Tab', '')) {
                button.classList.add('active');
            }
        });
    }

    segmentedControl.addEventListener('click', (e) => {
        const tab = e.target.dataset.tab;
        if (tab) {
            showTab(`${tab}Tab`);
        }
    });

    // --- User Avatar Dropdown Logic ---
    userAvatar.addEventListener('click', () => {
        userAvatarDropdown.classList.toggle('show');
    });
    // Close dropdown if clicked outside
    window.addEventListener('click', (e) => {
        if (!userAvatar.contains(e.target) && !userAvatarDropdown.contains(e.target) && !btnBackToHome.contains(e.target)) {
            userAvatarDropdown.classList.remove('show');
        }
    });

    // --- Load Profile Data ---
    async function loadProfileData() {
        const meRes = await API.get('/api/me');
        if (meRes.ok && meRes.data.status) {
            currentUser = meRes.data.data;
            if (currentUser) {
                // Update minimal header avatar
                userAvatar.textContent = currentUser.nama_lengkap ? currentUser.nama_lengkap.charAt(0).toUpperCase() : '?';
                // if (currentUser.profile_photo_url) { // Assuming a field for profile photo URL
                //     userAvatar.innerHTML = `<img src="${currentUser.profile_photo_url}" alt="Avatar">`;
                // }

                // Populate Profil Tab
                viewNip.textContent = currentUser.nip || '-';
                viewNamaLengkap.textContent = currentUser.nama_lengkap || '-';
                viewJabatan.textContent = currentUser.jabatan || '-';
                viewDepartemen.textContent = currentUser.departemen || '-';
                viewEmail.textContent = currentUser.email || '-';
                viewStatus.textContent = currentUser.status || '-';

                // Populate Edit Data Tab
                editNip.value = currentUser.nip || '';
                editNamaLengkap.value = currentUser.nama_lengkap || '';
                editJabatan.value = currentUser.jabatan || '';
                editDepartemen.value = currentUser.departemen || '';
                editEmail.value = currentUser.email || '';
                editStatus.value = currentUser.status || '';

                // Profile Photo Preview
                if (currentUser.profile_photo_path) { // Assuming a field for profile photo path
                    profileImagePreview.src = `/storage/${currentUser.profile_photo_path.replace(/^public\//,'')}`;
                    profileImagePreview.style.display = 'block';
                    profileInitials.style.display = 'none';
                    btnRemovePhoto.style.display = 'inline-block';
                } else {
                    profileImagePreview.style.display = 'none';
                    profileInitials.style.display = 'block';
                    profileInitials.textContent = currentUser.nama_lengkap ? currentUser.nama_lengkap.charAt(0).toUpperCase() : '?';
                    btnRemovePhoto.style.display = 'none';
                }

            }
        } else {
            toast(meRes.data?.message || 'Gagal memuat data profil.', 'err');
        }
    }

    // --- Profile Photo Upload Logic ---
    btnUploadPhoto.addEventListener('click', () => {
        photoUploadInput.click();
    });

    photoUploadInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
                profileImagePreview.src = event.target.result;
                profileImagePreview.style.display = 'block';
                profileInitials.style.display = 'none';
                btnRemovePhoto.style.display = 'inline-block';
                // TODO: Implement API call to upload photo
                toast('Foto profil berhasil diunggah (API call belum diimplementasikan).', 'info');
            };
            reader.readAsDataURL(file);
        }
    });

    btnRemovePhoto.addEventListener('click', async () => {
        if (confirm('Apakah Anda yakin ingin menghapus foto profil?')) {
            // TODO: Implement API call to remove photo
            toast('Foto profil berhasil dihapus (API call belum diimplementasikan).', 'info');
            profileImagePreview.src = '';
            profileImagePreview.style.display = 'none';
            profileInitials.style.display = 'block';
            profileInitials.textContent = currentUser.nama_lengkap ? currentUser.nama_lengkap.charAt(0).toUpperCase() : '?';
            btnRemovePhoto.style.display = 'none';
        }
    });


    // --- Edit Data Form Submission ---
    formEditProfile.addEventListener('submit', async (e) => {
        e.preventDefault();
        const payload = {
            nama_lengkap: editNamaLengkap.value.trim(),
            email: editEmail.value.trim(),
            // NIP, Jabatan, Departemen, Status are readonly, so not included in payload
        };

        try {
            const res = await API.put('/api/karyawan/profile', payload);
            if (res.ok && res.data.status) {
                toast('Profil berhasil diperbarui.');
                loadProfileData(); // Reload profile to reflect changes
            } else {
                toast(res.data?.message || 'Gagal memperbarui profil.', 'err');
            }
        } catch (error) {
            console.error('Error updating profile:', error);
            toast('Terjadi kesalahan saat memperbarui profil.', 'err');
        }
    });

    btnResetEditProfile.addEventListener('click', () => {
        if (currentUser) {
            editNamaLengkap.value = currentUser.nama_lengkap || '';
            editEmail.value = currentUser.email || '';
        }
    });

    // --- Change Password Form Submission ---
    formChangePassword.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (newPassword.value !== confirmNewPassword.value) {
            toast('Password baru dan konfirmasi password tidak cocok.', 'err');
            return;
        }

        const payload = {
            current: currentPassword.value,
            new: newPassword.value,
        };

        try {
            const res = await API.put('/api/karyawan/profile/password', payload);
            if (res.ok && res.data.status) {
                toast('Password berhasil diubah.');
                formChangePassword.reset(); // Clear password fields
            } else {
                toast(res.data?.message || 'Gagal mengubah password.', 'err');
            }
        } catch (error) {
            console.error('Error changing password:', error);
            toast('Terjadi kesalahan saat mengubah password.', 'err');
        }
    });

    // --- Logout ---
    btnLogout.onclick = async ()=>{ await API.post('/api/logout',{}); location.href='../login.html'; };

    // --- Dropdown Logout Button ---
    btnChangePasswordDropdown.addEventListener('click', () => {
        showTab('gantiPasswordTab');
        userAvatarDropdown.classList.remove('show');
    });

    // --- Back to Home Button ---
    btnBackToHome.onclick = () => {
        location.href = 'index.html'; // Navigate back to employee dashboard
    };

    // --- Initial Load ---
    loadProfileData();
    showTab('profilTab'); // Show default tab
});